/* global tableau */

let tableList;
let worksheetsList;
let selectedTable;
let selectedWorksheet;
let selectedWorksheetColumns;
let selectedTableColumns;
let columnMappingObj = {}

let columns = {}
function createDropdown(container, values) {

    let options = ""
    options = values.reduce((str,d) => str+ " <option value = '"+d+"' > " +d+ "</option> ",options)

    $("#"+container).html(options)
}
 
$(document).ready( function() {

    try { 
        tableau.extensions.initializeDialogAsync().then(async (OpenPayLoad)=> {
    
            let dashboard = tableau.extensions.dashboardContent.dashboard.name;
            
            worksheetsList = tableau.extensions.dashboardContent.dashboard.worksheets.map( (d,i) => d.name); 
                        
            tableList = await getTablesList();
            tableau.extensions.settings.set("tableList",tableList)
            tableList = JSON.parse(tableList)
            
            createDropdown("selectWorksheet", worksheetsList)
            createDropdown("selectTableName", tableList)

            if(worksheetsList && worksheetsList.length >0) {
                selectedWorksheet = worksheetsList[0]
                tableau.extensions.settings.set("selectedWorksheet",worksheetsList[0])
            }

            if(tableList && tableList.length >0) {
                selectedTable = tableList[0]
                tableau.extensions.settings.set("selectedTable",tableList[0])
            }
 
            selectedTableColumns = await getColumnsList();
            tableau.extensions.settings.set("selectedTableColumns",selectedTableColumns)
            selectedTableColumns = JSON.parse(selectedTableColumns)
                        
            let worksheetObj = tableau.extensions.dashboardContent.dashboard.worksheets.filter( (d,i) => d.name == selectedWorksheet )[0]
            let tabColumnsList = await worksheetObj.getSummaryColumnsInfoAsync();

            selectedWorksheetColumns = tabColumnsList.map( d=> d._fieldName)
            tableau.extensions.settings.set("selectedWorksheetColumns",JSON.stringify(selectedWorksheetColumns))

            populateSelectionDropdown();
        
        });       
    }catch (error){
        alert(error)
    }

    $("#save-config").on("click",saveSettings)

    $("#columns-mapping-div").on("change","select",(e)=>{  
            
        let columnName = $(e.target).attr('data-column-name')        
        columnMappingObj[columnName] = $(e.target).val()
        tableau.extensions.settings.set("columnMappingObj",JSON.stringify(columnMappingObj))

    })
});


function getTablesList(){

    return getDataFromServer("http://localhost:8081/schemas/get-all-schemas");
}

function getColumnsList(){

    return getDataFromServer("http://localhost:8081/schemas/get-columns?table_name=\""+selectedTable+"\"")
}

function getDataFromServer(url) {

        var requestOptions = {
            method: 'GET',
            redirect: 'follow'
        };
        
        return fetch(url, requestOptions).then(response => response.text());
}


function populateSelectionDropdown() {

        let i = 0;
        let selects = selectedWorksheetColumns.reduce( (str,v) => {

        let options = "<option disabled> Select Data Source Column </option>"
        options = selectedTableColumns.reduce((str,d) => str+ " <option value = '"+d.name+"' > " +d.name+ "</option> ",options)
        
        let selectContainer = `<div class="select-container">
                                    <label  class="form-label"> ${v} </label>
                                    <select class="form-select" data-column-name="${v}">
                                        ${options}
                                    </select>
                                </div>`

        columnMappingObj[v] =  selectedTableColumns[0].name;

        return str + selectContainer
    },"")

    $("#columns-mapping-div").html(selects)
    tableau.extensions.settings.set("columnMappingObj",JSON.stringify(columnMappingObj))
}

function saveSettings(){

    tableau.extensions.settings.saveAsync().then(result => {
        alert("Setting saved")
        tableau.extensions.ui.closeDialog('myPayload string');
     }).catch((error) => {
         alert("error")
     });
}