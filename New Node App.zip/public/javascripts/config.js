/* global tableau */

let tableList;
let worksheetsList;
let selectedTable;
let selectedWorksheet;
let selectedWorksheetColumns;
let selectedTableColumns;
let columnMappingObj = {}
let extensionType;
let isConfigured;
let primaryKey;
let formBuilder = {}

let columns = {}
function createDropdown(container, values) {

    try {

    let options = ""
    options = values.reduce((str,d) => str+ " <option value = '"+d+"' > " +d+ "</option> ",options)

    $("#"+container).html(options)

    }
    catch(e) {
        alert(e)
    }

}
 
$(document).ready( function() {

    try { 
        tableau.extensions.initializeDialogAsync().then(async (OpenPayLoad)=> {

            getSetting();

            let dashboard = tableau.extensions.dashboardContent.dashboard.name;
            
            worksheetsList = tableau.extensions.dashboardContent.dashboard.worksheets.map( (d,i) => d.name); 
            tableList = await getTablesList();
            tableList = JSON.parse(tableList)
            
        try{
            if(isConfigured == undefined || isConfigured == 'false') {

                extensionType = "addData"
                tableau.extensions.settings.set("extensionType","addData")                
                tableau.extensions.settings.set("tableList",JSON.stringify(tableList))
                
                if(worksheetsList && worksheetsList.length >0) {
                    selectedWorksheet = worksheetsList[0]
                    tableau.extensions.settings.set("selectedWorksheet",worksheetsList[0])
                }

                if(tableList && tableList.length >0) {
                    selectedTable = tableList[0]
                    tableau.extensions.settings.set("selectedTable",tableList[0])
                }

               
                selectedTableColumns = await getColumnsList();  
                tableau.extensions.settings.set("selectedTableColumns",selectedTableColumns)
                selectedTableColumns = JSON.parse(selectedTableColumns)

                let worksheetObj = tableau.extensions.dashboardContent.dashboard.worksheets.filter( (d,i) => d.name == selectedWorksheet )[0]
                let tabColumnsList = await worksheetObj.getSummaryColumnsInfoAsync();
    
                selectedWorksheetColumns = tabColumnsList.map( d=> d._fieldName)
                selectedWorksheetColumns = selectedWorksheetColumns.filter(d => d != 'username')
                tableau.extensions.settings.set("selectedWorksheetColumns",JSON.stringify(selectedWorksheetColumns))
                
                primaryKey = {}
                primaryKey['tableauField'] = selectedWorksheetColumns[0];
                primaryKey['dataSourceField'] = selectedTableColumns[0].name;
            }
        
        }catch(e){
            alert(e)
        }
            createDropdown("select-worksheet", worksheetsList)
            createDropdown("select-table-name", tableList)

            populateSelectionDropdown();
            populateKeySelectionDropdown()

            displayPreviousConfig();

            populateFormBuilder()

            loadPreviousFormBuilderSetting()

            if(isConfigured == 'true')
                loadPreviousSetting()
        });       
    }catch (error){
        alert(error)
    }

    $("#save-config").on("click",saveSettings)
    $("#save-formbuilder").on("click",saveSettings)

    $("#columns-mapping-div").on("change","select",(e)=>{  
            
        let columnName = $(e.target).attr('data-column-name')        
        columnMappingObj[columnName] = $(e.target).val()
        tableau.extensions.settings.set("columnMappingObj",JSON.stringify(columnMappingObj))

    })

    $("#extensionType").on('change',(event)=> {
    
        extensionType = ($(event.target).is(":checked"))?'addData':'updateData';
        tableau.extensions.settings.set("extensionType",extensionType)
        
        populateSelectionDropdown()
        populateKeySelectionDropdown()

        return
        
        if(extensionType == 'addData'){
            $("#primary-key-mapping-div").addClass("hide")
            $("#columns-mapping-container").removeClass("hide")
            populateSelectionDropdown()

        }
        else {
            $("#columns-mapping-container").addClass("hide")
            $("#primary-key-mapping-div").removeClass("hide")
            populateKeySelectionDropdown()
        }     
    })


    $("#formbuilder-table-div").on('change','input',(event)=> {
    
        let val = $(event.target).is(":checked")
        let colName = $(event.target).attr("data-col-name")
        let switchType = $(event.target).attr("data-switch-type")

        if(formBuilder.hasOwnProperty(selectedWorksheet)) {

            if(formBuilder[selectedWorksheet].hasOwnProperty(colName)) {

                formBuilder[selectedWorksheet][colName][switchType] =val

            }else {
                
                formBuilder[selectedWorksheet][colName] = {}
                formBuilder[selectedWorksheet][colName][switchType] =val
            }

        }else {
            formBuilder[selectedWorksheet]= {};
            formBuilder[selectedWorksheet][colName] = {}
            formBuilder[selectedWorksheet][colName][switchType] =val
        }

        
        tableau.extensions.settings.set("formBuilder",JSON.stringify(formBuilder))

        return
        
        if(extensionType == 'addData'){
            $("#primary-key-mapping-div").addClass("hide")
            $("#columns-mapping-container").removeClass("hide")
            populateSelectionDropdown()

        }
        else {
            $("#columns-mapping-container").addClass("hide")
            $("#primary-key-mapping-div").removeClass("hide")
            populateKeySelectionDropdown()
        }     
    })

    $("#select-table-name").on('change',async (e)=> {

        selectedTable = $(e.target).val();
        selectedTableColumns = await getColumnsList();
        tableau.extensions.settings.set("selectedTableColumns",selectedTableColumns)
        tableau.extensions.settings.set("selectedTable",selectedTable)
        selectedTableColumns = JSON.parse(selectedTableColumns)
        
        populateSelectionDropdown()
        populateKeySelectionDropdown()

        return
      
    })

    $("#select-worksheet").on('change',async (e)=> {
        
        selectedWorksheet = $(e.target).val();
        let worksheetObj = tableau.extensions.dashboardContent.dashboard.worksheets.filter( (d,i) => d.name == selectedWorksheet )[0]
        let tabColumnsList = await worksheetObj.getSummaryColumnsInfoAsync();
        
        selectedWorksheetColumns = tabColumnsList.map( d=> d._fieldName)
        selectedWorksheetColumns = selectedWorksheetColumns.filter(d => d != 'username')
        tableau.extensions.settings.set("selectedWorksheetColumns",JSON.stringify(selectedWorksheetColumns))
        tableau.extensions.settings.set("selectedWorksheet",selectedWorksheet)
        
        populateSelectionDropdown()
        populateKeySelectionDropdown()
        populateFormBuilder()
        loadPreviousFormBuilderSetting()

        return    
    })

    $("#tableau-field").on('change', (e) => {
        primaryKey['tableauField'] = $(e.target).val();
        tableau.extensions.settings.set("primaryKey",JSON.stringify(primaryKey))
    })
    
    $("#data-source-field").on('change', (e) => {
       primaryKey['dataSourceField'] = $(e.target).val();

       tableau.extensions.settings.set("primaryKey",JSON.stringify(primaryKey))
    })

});


function getSetting() {

    let settings = tableau.extensions.settings.getAll();
    
    isConfigured = settings['isConfigured']

    if(isConfigured) {
  
        selectedTable = settings['selectedTable'];
        selectedWorksheet = settings['selectedWorksheet']
        selectedWorksheetColumns = JSON.parse(settings['selectedWorksheetColumns'])
        selectedTableColumns = JSON.parse(settings['selectedTableColumns'])
        columnMappingObj = JSON.parse(settings['columnMappingObj'])
        extensionType = settings['extensionType']
        primaryKey  = JSON.parse(settings['primaryKey'])
        
        formBuilder  = JSON.parse(settings['formBuilder'])
    }
}

function getTablesList(){

    return getDataFromServer("http://localhost:8081/schemas/get-all-schemas");
}

function getColumnsList(){

    return getDataFromServer("http://localhost:8081/schemas/get-columns?table_name=\""+selectedTable+"\"")
}

function getDataFromServer(url) {

        var requestOptions = {
            method: 'GET',
            redirect: 'follow'
        };
        
        return fetch(url, requestOptions).then(response => response.text());
}


function populateSelectionDropdown() {


    let i = 0;
    let selects = selectedWorksheetColumns.reduce( (str,v) => {

        let options = "<option disabled> Select Data Source Column </option>"
        options = selectedTableColumns.reduce((str,d) => str+ " <option value = '"+d.name+"' > " +d.name+ "</option> ",options)
        
        let selectContainer = `<div class="select-container">
                                    <label  class="form-label"> ${v} </label>
                                    <select class="form-select" data-column-name="${v}" id = "${v.replace(/[^a-zA-Z0-9]/g,'_')}-field">
                                        ${options}
                                    </select>
                                </div>`

        //columnMappingObj[v] =  selectedTableColumns[0].name;

        return str + selectContainer
    },"")

    $("#columns-mapping-div").html(selects)
    //tableau.extensions.settings.set("columnMappingObj",JSON.stringify(columnMappingObj))
}


function populateKeySelectionDropdown() {

    let options = "<option disabled> Select Tableau Column </option>"
        options = selectedTableColumns.reduce((str,d) => str+ " <option value = '"+d.name+"' > " +d.name+ "</option> ",options)
    $("#data-source-field").html(options)

    options = "<option disabled> Select Data Source Column </option>"
    options = selectedWorksheetColumns.reduce((str,d) => str+ " <option value = '"+d+"' > " +d+ "</option> ",options)

    $("#tableau-field").html(options)
    tableau.extensions.settings.set("columnMappingObj",JSON.stringify(columnMappingObj))

}

function saveSettings(){

    tableau.extensions.settings.set("isConfigured",true)

    tableau.extensions.settings.saveAsync().then(result => {
        alert("Setting saved")
        tableau.extensions.ui.closeDialog('myPayload string');
     }).catch((error) => {
         alert("error")
     });
}

function displayPreviousConfig(){


}


function populateFormBuilder() {

    try {
        let i = 0;
        let tBody = selectedWorksheetColumns.reduce((trList,d) => {

        let  tr  = `
            <tr>
            <th scope="row">${++i}</th>
            <td>${d}</td>
            <td>
                <div class="form-check form-switch form-check-inline">
                <input class="form-check-input" data-switch-type="hide" type="checkbox" role="switch"  data-col-name="${d}" id="${d.replace(/[^a-zA-Z0-9]/g,'_')}-hide-switch">
                <label class="form-check-label" data-switch-type="readonly" data-col-name="${d}" for="${d.replace(/[^a-zA-Z0-9]/g,'_')}-hide-switch"> </label>
                </div>                    
            </td>
            <td>
                <div class="form-check form-switch form-check-inline">
                <input class="form-check-input"data-switch-type="readonly" data-col-name="${d}" type="checkbox" role="switch" id="${d.replace(/[^a-zA-Z0-9]/g,'_')}-readonly-switch">
                <label class="form-check-label" data-switch-type="readonly" data-col-name="${d}" for="${d.replace(/[^a-zA-Z0-9]/g,'_')}-readonly-switch"> </label>
                </div>
            </td>
            </tr>`

            return trList+" "+ tr
        }, "");

        $("#formbuilder-table-div > table > tbody").html(tBody)
    }
    catch(e) {
        alert(e)
    }
    
}

function loadPreviousFormBuilderSetting(){
    
     try { 
    if(formBuilder.hasOwnProperty(selectedWorksheet)) {
        selectedWorksheetColumns.forEach( (d,i) =>{
            if(formBuilder[selectedWorksheet].hasOwnProperty(d)) {

                let col = formBuilder[selectedWorksheet][d]
                let id = `#${d.replace(/[^a-zA-Z0-9]/g,'_')}-readonly-switch`;
                $(id).prop("checked",col['readonly'])

                id =`#${d.replace(/[^a-zA-Z0-9]/g,'_')}-hide-switch`
                $(id).prop("checked",col['hide'])
            }
        });        
    }
}catch (e) {
    alert(e)
}
}

function loadPreviousSetting() {

    $("#select-worksheet").val(selectedWorksheet)
    $("#select-table-name").val(selectedTable)

    $("#tableau-field").val(primaryKey['tableauField'])
    $("#data-source-field").val(primaryKey['dataSourceField'] )

       

    selectedWorksheetColumns.forEach( (d,i)=> {

try {
        if(columnMappingObj.hasOwnProperty(d)) {
            
           $(`#${d.replace(/[^a-zA-Z0-9]/g,'_')}-field`).val(columnMappingObj[d])
        }else {
            columnMappingObj[d] =  selectedTableColumns[0].name;
        }
}catch(e){
    alert(e)
}
    })
    
    tableau.extensions.settings.set("columnMappingObj",JSON.stringify(columnMappingObj))
}